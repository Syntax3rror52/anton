<?php

$servername = "localhost";
$username="root";
$password="";
$dbname="registrationform";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$errors = array();
?>